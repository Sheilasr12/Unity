# Dynamixel SDK

This package has been forked from the official [dynamixel_sdk](https://github.com/ROBOTIS-GIT/DynamixelSDK) package. 

It has been adapted to work on the Niryo custom Raspberry Pi 3 shield, using the [wiringPi](http://wiringpi.com/) library.
